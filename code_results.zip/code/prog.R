library("mnormt")
library("MaXact")
library("mvtnorm")
library("mvnormtest")


#generate geno_pro under H_1
cal.geno.prop <- function(K, MAF, lambda.1, lambda.2)
{
  g0 <- (1-MAF)^2
  g1 <- 2*MAF*(1-MAF)
  g2 <- MAF^2
  
  f0 <- K/(g0+lambda.1*g1+lambda.2*g2)
  f1 <- lambda.1*f0
  f2 <- lambda.2*f0
  
  p.case <- cbind(f0*g0/K, f1*g1/K, f2*g2/K)
  p.ctrl <- cbind((1-f0)*g0/(1-K), (1-f1)*g1/(1-K), (1-f2)*g2/(1-K))
  
  cbind(p.case, p.ctrl)
}


#generate geno_pro under H_0
cal.geno.prop_H0 <- function(MAF)
{
  p0 = (1-MAF)^2
  q0 = p0
  p1 = 2*MAF*(1-MAF)
  q1 = p1
  p2 = MAF^2
  q2 = p2
  c(p0,p1,p2,q0,q1,q2)
}

#Simulation



##calculate the correlation coefficient
cal.corr <- function(p.case,p.ctrl,n.case,n.ctrl)
{
  n <- n.case+n.ctrl
  phi <- n.case/n
  v0 <- (1-phi)*p.case[3]*(1-p.case[3])+phi*p.ctrl[3]*(1-p.ctrl[3])
  v1 <- (1-phi)*(p.case[1]*p.case[2]+p.case[2]*p.case[3]+4*p.case[1]*p.case[3])
  +phi*(p.ctrl[1]*p.ctrl[2]+p.ctrl[2]*p.ctrl[3]+4*p.ctrl[1]*p.ctrl[3])
  v2 <- (1-phi)*p.case[1]*(1-p.case[1])+phi*p.ctrl[1]*(1-p.ctrl[1])
  cor.RA <- ((1-phi)*p.case[3]*(2*p.case[1]+p.case[2])
             +phi*p.ctrl[3]*(2*p.ctrl[1]+p.ctrl[2]))/sqrt(v0*v1)
  cor.RD <- ((1-phi)*p.case[1]*p.case[3]+phi*p.ctrl[1]*p.ctrl[3])/sqrt(v0*v2)
  cor.AD <- ((1-phi)*p.case[1]*(2*p.case[3]+p.case[2])
             +phi*p.ctrl[1]*(2*p.ctrl[3]+p.ctrl[2]))/sqrt(v2*v1)
  c(cor.RA,cor.RD,cor.AD)
}

##calculate max statistics
mod3.stat <- function(x)
{
  ri <- x[1:3]
  si <- x[4:6]
  T.rec <- trend.test(0.0,ri=ri,si=si,abs.flag=0)
  T.add <- trend.test(0.5,ri=ri,si=si,abs.flag=0)
  T.dom <- trend.test(1,ri=ri,si=si,abs.flag=0)
  c(T.rec,T.add,T.dom)
}

##Trend.test
trend.test <- function(x,ri=c(1,2,3),si=c(1,2,3),abs.flag=1)
{
  phi <- c(0,x,1)
  ni <- ri+si+1e-10
  r <- sum(ri)
  s1 <- sum(si)
  n <- r+s1
  numerator <- sqrt(n)*sum(phi*(s1*ri-r*si))
  denominator <- sqrt(r*s1*(n*sum(phi^2*ni)-(sum(phi*ni))^2))
  z <- numerator/denominator
  ifelse(abs.flag,abs(z),z)
}

##to calculate p.value based on joint-analysis max test using monterCarlo method
cal.pvalue.max.1 <- function(stage1.data,stage2.data,n.replicate=10,n.monterCarlo=1e7)
{
  pii <- sum(stage1.data)/sum(stage1.data+stage2.data)
  w1 <- sqrt(pii)
  w2 <- sqrt(1-pii)
  t1 <- mod3.stat(c(stage1.data[1,],stage1.data[2,]))
  t.max.1 <- max(abs(t1))
  t2 <- mod3.stat(c(stage2.data[1,],stage2.data[2,]))
  t.max.j <- max(abs(t1*sqrt(pii)+t2*sqrt(1-pii)))
  
  p.null.1 <- (stage1.data[1,]+stage1.data[2,])/sum(stage1.data)
  temp <- cal.corr(p.null.1,p.null.1,sum(stage1.data[1,]),sum(stage1.data[2,]))
  rho.ra.1 <- temp[1]
  rho.rd.1 <- temp[2]
  rho.ad.1 <- temp[3]
  let.1 <- 1-rho.rd.1^2
  w0.star <- (rho.ra.1-rho.rd.1*rho.ad.1)/let.1
  w1.star <- (rho.ad.1-rho.rd.1*rho.ra.1)/let.1
  sigma.1 <- matrix(c(1,rho.rd.1,rho.rd.1,1),ncol = 2)
  
  p.null.2 <- (stage2.data[1,]+stage2.data[2,])/sum(stage2.data)
  temp <- cal.corr(p.null.2,p.null.2,sum(stage2.data[1,]),sum(stage2.data[2,]))
  rho.ra.2 <- temp[1]
  rho.rd.2 <- temp[2]
  rho.ad.2 <- temp[3]
  let.2 <- 1-rho.rd.2^2
  k0.star <- (rho.ra.2-rho.rd.2*rho.ad.2)/let.2
  k1.star <- (rho.ad.2-rho.rd.2*rho.ra.2)/let.2
  sigma.2 <- matrix(c(1,rho.rd.2,rho.rd.2,1),ncol = 2)
  
  n0 <- 0
  n1 <- 0
  for (i in 1:n.replicate) {
    A1 <- rmvnorm(n.monterCarlo,mean = c(0,0),sigma = sigma.1)
    B1 <- cbind(A1[,1],w0.star*A1[,1]+w1.star*A1[,2],A1[,2])
    v1 <- apply(abs(B1), 1, max)
    
    A2 <- rmvnorm(n.monterCarlo,mean=c(0,0),sigma = sigma.2)
    B2 <- cbind(A2[,1],k0.star*A2[,1]+k1.star*A2[,2],A2[,2])
    temp <- B1*w1 + B2*w2
    vj <- apply(abs(temp), 1, max)
    n0 <- n0+sum(v1>t.max.1 & vj>t.max.j)
    n1 <- n1+n.monterCarlo
  }
  n0/n1
}



# power of maxact 
power_maxact <- function(freq.1,freq.2,num.simu,Gamma,alpha,exact=TRUE,m){
  p1 <- rep(0,num.simu)
  results1 = rep(NA,num.simu)
  n = 0
  for (i in seq(num.simu)){
    stage1.data = matrix(freq.1[i,],byrow = TRUE,ncol=3)
    stage2.data = matrix(freq.2[i,],byrow = TRUE,ncol=3)
    p_1 <- MaXact::maxact.test(stage1.data,exact = exact)
    p1[i] <- (p_1$p.value)
  #print("p1")
  #print(p1)
    if (p1[i] < Gamma){
      n = n + 1
      p_2 <- MaXact::maxact.test(stage1.data+stage2.data,exact = exact)
      results1[i] = p_2$p.value
     }
  }
  test.power1 <- sum(na.omit(results1) < alpha/m)/ num.simu
  #print("#sum of p")
  #print(sum(na.omit(results1) < alpha/m))
  #print("#n")
  #print(n)
  return(test.power1)
}

# power of max test 
power_max <- function(freq.1,freq.2,num.simu,Gamma,alpha,m){
  num.simu = num.simu/2
  results2 = rep(NA,num.simu)
  for (i in seq(num.simu)) {
    stage1.data = matrix(freq.1[i,],byrow = TRUE,ncol=3)
    stage2.data = matrix(freq.2[i,],byrow = TRUE,ncol=3)
    p_m <- cal.pvalue.max.1(stage1.data = stage1.data,stage2.data = stage2.data,n.replicate = 10,n.monterCarlo = 1e4)
    results2[i] <- p_m
    print(i*100/num.simu)
    #print(p_m)
  }
  test.power2 <- sum(na.omit(results2) < alpha/m)/ num.simu
  return(test.power2)
}

## calculate the power and type 1 error (POWER=True shows that calculate power otherwise type I error)
power_error <- function(K=0.1, MAF=0.15, lambda.1=1, lambda.2=2, m= 5e5, alpha=0.05, Gamma=0.0001, n.case=4000, n.ctrl=4000, pii=0.3, num.simu=10000,POWER = TRUE)
{
  if(POWER){
    p <- cal.geno.prop(K, MAF, lambda.1, lambda.2)  # prob under H1
  }
  else {
    p <- cal.geno.prop_H0(MAF) #prob under H0
  }
    
  
  freq.1.case <- t(rmultinom(num.simu, n.case*pii, p[1:3])) #产生多项分布num.sium次，R=n.case*pii
  freq.1.ctrl <- t(rmultinom(num.simu, n.ctrl*pii, p[4:6]))
  freq.1 <- cbind(freq.1.case, freq.1.ctrl) #第一阶段列联�?2X3
  
  freq.2.case <- t(rmultinom(num.simu, n.case*(1-pii), p[1:3])) 
  freq.2.ctrl <- t(rmultinom(num.simu, n.ctrl*(1-pii), p[4:6]))
  freq.2 <- cbind(freq.2.case, freq.2.ctrl) #第二阶段列联�?2X3

  time_s1 <- Sys.time()
  test_power1 <- power_maxact(freq.1,freq.2,num.simu,Gamma,alpha,exact = TRUE,m)
  time_e1 <- Sys.time()
  time1 <- time_e1-time_s1
  print(test_power1)
  
  time_s2 <- Sys.time()
  test_power2 <- power_maxact(freq.1,freq.2,num.simu,Gamma,alpha,exact = FALSE,m)
  print(test_power2)
  time_e2 <- Sys.time()
  time2 <- time_e2-time_s2
  
  time_s3 <- Sys.time()
  test_power3 <- power_max(freq.1,freq.2,num.simu,Gamma,alpha,m)
  #print(test_power3)
  time_e3 <- Sys.time()
  time3 <- time_e3-time_s3
  
  #print(test_power3)
  return(data.frame(test_power1,time1,test_power2,time2,test_power3,time3))
}

# calculate the power
#table1
table11 <- power_error(K=0.1, MAF=0.15, lambda.1=1, lambda.2=2, m=5e5, alpha=0.05, Gamma=0.0001, n.case=5000, n.ctrl=5000, pii=0.5, num.simu=10000,POWER = TRUE)
write.table(table12,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table12.txt")
table12 <- power_error(K=0.1, MAF=0.15, lambda.1=1, lambda.2=2, m=5e5, alpha=0.05, Gamma=0.0002, n.case=5000, n.ctrl=5000, pii=0.5, num.simu=10000,POWER = TRUE)
write.table(table12,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table12.txt")

table13 <- power_error(K=0.1, MAF=0.15, lambda.1=1, lambda.2=2, m=5e5, alpha=0.05, Gamma=0.0001, n.case=5000, n.ctrl=5000, pii=0.4, num.simu=10000,POWER = TRUE)
write.table(table14,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table14.txt")
table14 <- power_error(K=0.1, MAF=0.15, lambda.1=1, lambda.2=2, m=5e5, alpha=0.05, Gamma=0.0002, n.case=5000, n.ctrl=5000, pii=0.4, num.simu=10000,POWER = TRUE)
write.table(table14,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table14.txt")

table15 <- power_error(K=0.1, MAF=0.15, lambda.1=1, lambda.2=2, m=5e5, alpha=0.05, Gamma=0.0001, n.case=5000, n.ctrl=5000, pii=0.3, num.simu=10000,POWER = TRUE)
write.table(table15,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table15.txt")
table16 <- power_error(K=0.1, MAF=0.15, lambda.1=1, lambda.2=2, m=5e5, alpha=0.05, Gamma=0.0002, n.case=5000, n.ctrl=5000, pii=0.3, num.simu=10000,POWER = TRUE)
write.table(table16,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table16.txt")

###
table17 <- power_error(K=0.1, MAF=0.35, lambda.1=1, lambda.2=1.5, m=5e5, alpha=0.05, Gamma=0.0001, n.case=4000, n.ctrl=4000, pii=0.5, num.simu=10000,POWER = TRUE)
write.table(table17,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table17.txt")
table18 <- power_error(K=0.1, MAF=0.35, lambda.1=1, lambda.2=1.5, m=5e5, alpha=0.05, Gamma=0.0002, n.case=4000, n.ctrl=4000, pii=0.5, num.simu=10000,POWER = TRUE)
write.table(table18,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table18.txt")

table19 <- power_error(K=0.1, MAF=0.35, lambda.1=1, lambda.2=1.5, m=5e5, alpha=0.05, Gamma=0.0001, n.case=5000, n.ctrl=5000, pii=0.4, num.simu=10000,POWER = TRUE)
write.table(table19,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table19.txt")
table110 <- power_error(K=0.1, MAF=0.35, lambda.1=1, lambda.2=1.5, m=5e5, alpha=0.05, Gamma=0.0002, n.case=5000, n.ctrl=5000, pii=0.4, num.simu=10000,POWER = TRUE)
write.table(table110,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table110.txt")

table111 <- power_error(K=0.1, MAF=0.35, lambda.1=1, lambda.2=1.5, m=5e5, alpha=0.05, Gamma=0.0001, n.case=4000, n.ctrl=4000, pii=0.3, num.simu=10000,POWER = TRUE)
write.table(table111,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table111.txt")
table112 <- power_error(K=0.1, MAF=0.35, lambda.1=1, lambda.2=1.5, m=5e5, alpha=0.05, Gamma=0.0002, n.case=5000, n.ctrl=5000, pii=0.3, num.simu=10000,POWER = TRUE)
write.table(table112,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table112.txt")


### table2
table2_1 <- power_error(K=0.1, MAF=0.15, lambda.1=1.4, lambda.2=1.8, m=5e5, alpha=0.05, Gamma=0.0001, n.case=2000, n.ctrl=2000, pii=0.5, num.simu=10000,POWER = TRUE)
write.table(table2_1,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table2_1.txt")
table2_2 <- power_error(K=0.1, MAF=0.15, lambda.1=1.4, lambda.2=1.8, m=5e5, alpha=0.05, Gamma=0.0002, n.case=2000, n.ctrl=2000, pii=0.5, num.simu=10000,POWER = TRUE)
write.table(table2_2,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table2_2.txt")

table2_3 <- power_error(K=0.1, MAF=0.15, lambda.1=1.4, lambda.2=1.8, m=5e5, alpha=0.05, Gamma=0.0001, n.case=2000, n.ctrl=2000, pii=0.4, num.simu=100000,POWER = TRUE)
write.table(table2_3,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table2_3.txt")
table2_4 <- power_error(K=0.1, MAF=0.15, lambda.1=1.4, lambda.2=1.8, m=5e5, alpha=0.05, Gamma=0.0002, n.case=2000, n.ctrl=2000, pii=0.4, num.simu=100000,POWER = TRUE)
write.table(table2_4,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table2_4.txt")

table2_5 <- power_error(K=0.1, MAF=0.15, lambda.1=1.4, lambda.2=1.8, m=5e5, alpha=0.05, Gamma=0.0001, n.case=2000, n.ctrl=2000, pii=0.3, num.simu=10000,POWER = TRUE)
write.table(table2_5,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table2_5.txt")
table2_6 <- power_error(K=0.1, MAF=0.15, lambda.1=1.4, lambda.2=1.8, m=5e5, alpha=0.05, Gamma=0.0002, n.case=2000, n.ctrl=2000, pii=0.3, num.simu=10000,POWER = TRUE)
write.table(table2_6,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table2_6.txt")

###
table2_7 <- power_error(K=0.1, MAF=0.35, lambda.1=1.4, lambda.2=1.8, m=5e5, alpha=0.05, Gamma=0.0001, n.case=2000, n.ctrl=2000, pii=0.5, num.simu=10000,POWER = TRUE)
write.table(table2_7,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table2_7.txt")
table2_8 <- power_error(K=0.1, MAF=0.35, lambda.1=1.4, lambda.2=1.8, m=5e5, alpha=0.05, Gamma=0.0002, n.case=2000, n.ctrl=2000, pii=0.5, num.simu=10000,POWER = TRUE)
write.table(table2_8,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table2_8.txt")

table2_9 <- power_error(K=0.1, MAF=0.35, lambda.1=1.4, lambda.2=1.8, m=5e5, alpha=0.05, Gamma=0.0001, n.case=2000, n.ctrl=2000, pii=0.4, num.simu=10000,POWER = TRUE)
write.table(table2_9,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table2_9.txt")
table2_10 <- power_error(K=0.1, MAF=0.35, lambda.1=1.4, lambda.2=1.8, m=5e5, alpha=0.05, Gamma=0.0002, n.case=2000, n.ctrl=2000, pii=0.4, num.simu=10000,POWER = TRUE)
write.table(table2_10,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table2_10.txt")

table2_11 <- power_error(K=0.1, MAF=0.35, lambda.1=1.4, lambda.2=1.8, m=5e5, alpha=0.05, Gamma=0.0001, n.case=2000, n.ctrl=2000, pii=0.3, num.simu=10000,POWER = TRUE)
write.table(table2_11,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table2_11.txt")
table2_12 <- power_error(K=0.1, MAF=0.35, lambda.1=1.4, lambda.2=1.8, m=5e5, alpha=0.05, Gamma=0.0002, n.case=2000, n.ctrl=2000, pii=0.3, num.simu=10000,POWER = TRUE)
write.table(table2_12,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table2_12.txt")

### table3
table3_1 <- power_error(K=0.1, MAF=0.15, lambda.1=1.5, lambda.2=1.5, m=5e5, alpha=0.05, Gamma=0.0001, n.case=2000, n.ctrl=2000, pii=0.5, num.simu=10000,POWER = TRUE)
write.table(table3_1,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table3_1.txt")
table3_2 <- power_error(K=0.1, MAF=0.15, lambda.1=1.5, lambda.2=1.5, m=5e5, alpha=0.05, Gamma=0.0002, n.case=2000, n.ctrl=2000, pii=0.5, num.simu=10000,POWER = TRUE)
write.table(table3_2,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table3_2.txt")

table3_3 <- power_error(K=0.1, MAF=0.15, lambda.1=1.5, lambda.2=1.5, m=5e5, alpha=0.05, Gamma=0.0001, n.case=2000, n.ctrl=2000, pii=0.4, num.simu=10000,POWER = TRUE)
write.table(table3_3,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table3_3.txt")
table3_4 <- power_error(K=0.1, MAF=0.15, lambda.1=1.5, lambda.2=1.5, m=5e5, alpha=0.05, Gamma=0.0002, n.case=2000, n.ctrl=2000, pii=0.4, num.simu=10000,POWER = TRUE)
write.table(table3_4,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table3_4.txt")

table3_5 <- power_error(K=0.1, MAF=0.15, lambda.1=1.5, lambda.2=1.5, m=5e5, alpha=0.05, Gamma=0.0001, n.case=2000, n.ctrl=2000, pii=0.3, num.simu=10000,POWER = TRUE)
write.table(table3_5,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table3_5.txt")
table3_6 <- power_error(K=0.1, MAF=0.15, lambda.1=1.5, lambda.2=1.5, m=5e5, alpha=0.05, Gamma=0.0002, n.case=2000, n.ctrl=2000, pii=0.3, num.simu=10000,POWER = TRUE)
write.table(table3_6,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table3_6.txt")

###
table3_7 <- power_error(K=0.1, MAF=0.35, lambda.1=1.5, lambda.2=1.5, m=5e5, alpha=0.05, Gamma=0.0001, n.case=2000, n.ctrl=2000, pii=0.5, num.simu=10000,POWER = TRUE)
write.table(table3_7,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table3_7.txt")
table3_8 <- power_error(K=0.1, MAF=0.35, lambda.1=1.5, lambda.2=1.5, m=5e5, alpha=0.05, Gamma=0.0002, n.case=2000, n.ctrl=2000, pii=0.5, num.simu=10000,POWER = TRUE)
write.table(table3_8,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table3_8.txt")

table3_9 <- power_error(K=0.1, MAF=0.35, lambda.1=1.5, lambda.2=1.5, m=5e5, alpha=0.05, Gamma=0.0001, n.case=2000, n.ctrl=2000, pii=0.4, num.simu=10000,POWER = TRUE)
write.table(table3_9,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table3_9.txt")
table3_10 <- power_error(K=0.1, MAF=0.35, lambda.1=1.5, lambda.2=1.5, m=1e3, alpha=0.05, Gamma=0.0002, n.case=2000, n.ctrl=2000, pii=0.4, num.simu=10000,POWER = TRUE)
write.table(table3_10,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table3_10.txt")

table3_11 <- power_error(K=0.1, MAF=0.35, lambda.1=1.5, lambda.2=1.5, m=5e5, alpha=0.05, Gamma=0.0001, n.case=2000, n.ctrl=2000, pii=0.3, num.simu=10000,POWER = TRUE)
write.table(table3_11,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table3_11.txt")
table3_12 <- power_error(K=0.1, MAF=0.35, lambda.1=1.5, lambda.2=1.5, m=5e5, alpha=0.05, Gamma=0.0002, n.case=2000, n.ctrl=2000, pii=0.3, num.simu=10000,POWER = TRUE)
write.table(table3_12,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results2\\table3_12.txt")



##calculate the type I error
table11 <- power_error(K=0.1, MAF=0.15, lambda.1=1, lambda.2=2, m=1e2, alpha=0.05, Gamma=0.005, n.case=5000, n.ctrl=5000, pii=0.5, num.simu=100000,POWER = FALSE)
write.table(table11,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results3\\table11.txt")

table13 <- power_error(K=0.1, MAF=0.15, lambda.1=1, lambda.2=2, m=1e2, alpha=0.05, Gamma=0.005, n.case=5000, n.ctrl=5000, pii=0.4, num.simu=100000,POWER = FALSE)
write.table(table13,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results3\\table13.txt")

table15 <- power_error(K=0.1, MAF=0.15, lambda.1=1, lambda.2=2, m=1e3, alpha=0.05, Gamma=0.005, n.case=5000, n.ctrl=5000, pii=0.3, num.simu=100000,POWER = FALSE)
write.table(table15,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results3\\table15.txt")

table17 <- power_error(K=0.1, MAF=0.35, lambda.1=1, lambda.2=1.5, m=1e3, alpha=0.05, Gamma=0.005, n.case=4000, n.ctrl=4000, pii=0.5, num.simu=100000,POWER = FALSE)
write.table(table17,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results3\\table17.txt")

table19 <- power_error(K=0.1, MAF=0.35, lambda.1=1, lambda.2=1.5, m=1e2, alpha=0.05, Gamma=0.005, n.case=5000, n.ctrl=5000, pii=0.4, num.simu=100000,POWER = FALSE)
write.table(table19,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results3\\table19.txt")

table111 <- power_error(K=0.1, MAF=0.35, lambda.1=1, lambda.2=1.5, m=1e2, alpha=0.05, Gamma=0.005, n.case=4000, n.ctrl=4000, pii=0.3, num.simu=100000,POWER = FALSE)
write.table(table111,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results3\\table111.txt")

###
table2_1 <- power_error(K=0.1, MAF=0.15, lambda.1=1.4, lambda.2=1.8, m=1e2, alpha=0.05, Gamma=0.005, n.case=2000, n.ctrl=2000, pii=0.5, num.simu=100000,POWER = FALSE)
write.table(table2_1,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results3\\table2_1.txt")


table2_3 <- power_error(K=0.1, MAF=0.15, lambda.1=1.4, lambda.2=1.8, m=1e3, alpha=0.05, Gamma=0.005, n.case=2000, n.ctrl=2000, pii=0.4, num.simu=1000000,POWER = FALSE)
write.table(table2_3,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results3\\table2_3.txt")

table2_5 <- power_error(K=0.1, MAF=0.15, lambda.1=1.4, lambda.2=1.8, m=1e2, alpha=0.05, Gamma=0.005, n.case=2000, n.ctrl=2000, pii=0.3, num.simu=100000,POWER = FALSE)
write.table(table2_5,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results3\\table2_5.txt")

table2_7 <- power_error(K=0.1, MAF=0.35, lambda.1=1.4, lambda.2=1.8, m=1e2, alpha=0.05, Gamma=0.005, n.case=2000, n.ctrl=2000, pii=0.5, num.simu=100000,POWER = FALSE)
write.table(table2_7,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results3\\table2_7.txt")

table2_9 <- power_error(K=0.1, MAF=0.35, lambda.1=1.4, lambda.2=1.8, m=1e2, alpha=0.05, Gamma=0.005, n.case=2000, n.ctrl=2000, pii=0.4, num.simu=100000,POWER = FALSE)
write.table(table2_9,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results3\\table2_9.txt")

table2_11 <- power_error(K=0.1, MAF=0.35, lambda.1=1.4, lambda.2=1.8, m=1e3, alpha=0.05, Gamma=0.005, n.case=2000, n.ctrl=2000, pii=0.3, num.simu=100000,POWER = FALSE)
write.table(table2_11,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results3\\table2_11.txt")

###
table3_1 <- power_error(K=0.1, MAF=0.15, lambda.1=1.5, lambda.2=1.5, m=1e3, alpha=0.05, Gamma=0.005, n.case=2000, n.ctrl=2000, pii=0.5, num.simu=100000,POWER = FALSE)
write.table(table3_1,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results3\\table3_1.txt")

table3_3 <- power_error(K=0.1, MAF=0.15, lambda.1=1.5, lambda.2=1.5, m=1e3, alpha=0.05, Gamma=0.005, n.case=2000, n.ctrl=2000, pii=0.4, num.simu=100000,POWER = FALSE)
write.table(table3_3,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results3\\table3_3.txt")

table3_5 <- power_error(K=0.1, MAF=0.15, lambda.1=1.5, lambda.2=1.5, m=1e3, alpha=0.05, Gamma=0.005, n.case=2000, n.ctrl=2000, pii=0.3, num.simu=100000,POWER = FALSE)
write.table(table3_5,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results3\\table3_5.txt")

table3_7 <- power_error(K=0.1, MAF=0.35, lambda.1=1.5, lambda.2=1.5, m=1e3, alpha=0.05, Gamma=0.005, n.case=2000, n.ctrl=2000, pii=0.5, num.simu=100000,POWER = FALSE)
write.table(table3_7,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results3\\table3_7.txt")

table3_9 <- power_error(K=0.1, MAF=0.35, lambda.1=1.5, lambda.2=1.5, m=1e2, alpha=0.05, Gamma=0.005, n.case=2000, n.ctrl=2000, pii=0.4, num.simu=100000,POWER = FALSE)
write.table(table3_9,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results3\\table3_9.txt")

table3_11 <- power_error(K=0.1, MAF=0.35, lambda.1=1.5, lambda.2=1.5, m=1e2, alpha=0.05, Gamma=0.005, n.case=2000, n.ctrl=2000, pii=0.3, num.simu=100000,POWER = FALSE)
write.table(table3_11,file = "C:\\Users\\yisong\\Desktop\\translate\\simulation_results3\\table3_11.txt")
